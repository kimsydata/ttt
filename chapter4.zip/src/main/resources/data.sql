INSERT INTO member (id, name) VALUES (1, '이름1')
INSERT INTO member (id, name) VALUES (2, '이름2')
INSERT INTO member (id, name) VALUES (3, '이름3')
